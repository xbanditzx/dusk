function dragstart_handler(ev) {
    ev.dataTransfer.setData("text/plain", ev.target.id);
  }

window.addEventListener("DOMContentLoaded", () => {
    const element = document.getElementById("p1");
    element.addEventListener("dragstart", dragstart_handler);
  });
